Images — Wanderlust Trails
===========================

This folder is reserved for locally-stored image assets (logo files,
icons, illustrations) as the site grows.

Per the task's content guidelines, most imagery is currently pulled
live from free sources rather than stored here:

- Destination / package photos: Unsplash (via the "images.unsplash.com"
  source URLs referenced directly in js/data.js).
- Placeholder fallbacks: placehold.co, e.g. https://placehold.co/800x600
- Non-destination illustrations (empty states, onboarding, etc.):
  Undraw / Storyset / Freepik — to be downloaded and added here as
  those sections are built (booking confirmation, dashboard empty
  states, 404 page).

When real assets are downloaded for production, save them here using
descriptive names, e.g.:
  images/logo-wordmark.svg
  images/icon-compass.svg
  images/illustration-empty-wishlist.svg
